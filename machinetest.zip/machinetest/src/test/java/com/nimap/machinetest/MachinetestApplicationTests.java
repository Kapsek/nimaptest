package com.nimap.machinetest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MachinetestApplicationTests {

	@Test
	void contextLoads() {
	}

}
