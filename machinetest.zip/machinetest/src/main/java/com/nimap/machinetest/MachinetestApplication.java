package com.nimap.machinetest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MachinetestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MachinetestApplication.class, args);
	}

}
